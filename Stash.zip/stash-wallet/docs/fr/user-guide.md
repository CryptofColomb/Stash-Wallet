# Guide de l'utilisateur – Stash Wallet

## 1. Introduction
Stash Wallet est un portefeuille cryptographique multi-chaîne conçu pour des opérations hors ligne sécurisées.

## 2. Installation
1. Décompressez le fichier ZIP.
2. Utilisez le script `scripts/usb-deploy.sh` pour écrire sur l'USB.
3. Insérez la clé USB et l'interface s'ouvrira automatiquement.
4. Transférez les transactions via QR ou fichier.