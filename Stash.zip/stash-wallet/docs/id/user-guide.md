# Panduan Pengguna – Stash Wallet

## 1. Pengantar
Stash Wallet adalah dompet kripto multi-rantai yang dirancang untuk operasi offline yang aman.

## 2. Instalasi
1. Ekstrak file ZIP.
2. Gunakan skrip `scripts/usb-deploy.sh` untuk menulis ke USB.
3. Masukkan USB dan antarmuka akan terbuka otomatis.
4. Lakukan transaksi melalui QR atau file.