# Dompet Stash

Stash Wallet adalah dompet kripto multi-rantai yang dirancang untuk operasi offline yang aman.

## Fitur
- Dukungan multi-rantai (Ethereum, Bitcoin, Solana, TRON, BSC, Polygon, Avalanche)
- Tanda tangan transaksi melalui QR Code dan file
- Enkripsi AES-256 dengan perlindungan PIN
- Transfer lintas rantai (LayerZero, Wormhole, Stargate)
- Sistem deposit fiat (USD/EUR/GBP)
- Sistem staking dengan diskon 30%
- Sistem referral (maksimal 10 pengguna, hadiah 1 stAG)