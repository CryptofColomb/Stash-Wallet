# Mwongozo wa Mtumiaji – Stash Wallet

## 1. Ujanibisho
Stash Wallet ni mfuko wa blockchain mbalimbali ulio sanidhia kwa maombi ya hewa salama.

## 2. Usanidi
1. Tofauti ZIP.
2. Tumia skripti ya `scripts/usb-deploy.sh` kuyaweka kwenye USB.
3. Ingiza USB na kuingia kitanuka.
4. Thamani zinazopitishwa kwa QR au faili.