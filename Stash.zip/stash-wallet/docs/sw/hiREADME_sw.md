# Stash Wallet

Stash Wallet ni mfuko wa kificho kinachosaidia matumizi ya blockchain mbalimbali kwa usalama wa hifadhi za hewa.

## Zile sifa
- Usaidizi wa blockchain mbalimbali (Ethereum, Bitcoin, Solana, TRON, BSC, Polygon, Avalanche)
- Imzajibika ya malipo kwa QR na faili
- Usifraji wa AES-256 na ulinzi wa PIN
- Matumizi ya Chain za usafiri (LayerZero, Wormhole, Stargate)
- MFumo wa kuhifadhi Fedha ya Kira (USD/EUR/GBP)
- MFumo wa kuchukua pesa kwa punguzo la 30%
- MFumo wa kurekomendia (mpaka wa watumiaji 10, zawadi ya 1 stAG)