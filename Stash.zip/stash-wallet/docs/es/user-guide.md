# Guía de Usuario – Stash Wallet

## 1. Introducción
Stash Wallet es una billetera criptográfica multi-cadena diseñada para operaciones seguras sin conexión.

## 2. Instalación
1. Descomprime el archivo ZIP.
2. Usa el script `scripts/usb-deploy.sh` para escribir en USB.
3. Inserta el USB y la interfaz se abrirá automáticamente.
4. Transfiere transacciones por QR o archivo.