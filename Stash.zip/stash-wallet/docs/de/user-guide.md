# Benutzerhandbuch – Stash Wallet

## 1. Einführung
Stash Wallet ist eine Multi-Chain-Kryptowallet für sichere Offline-Transaktionen.

## 2. Installation
1. Entpacken Sie die ZIP-Datei.
2. Verwenden Sie das Skript `scripts/usb-deploy.sh`, um auf den USB zu schreiben.
3. Stecken Sie den USB-Stick ein. Die Oberfläche öffnet sich automatisch.
4. Transaktionen per QR-Code oder Datei übertragen.