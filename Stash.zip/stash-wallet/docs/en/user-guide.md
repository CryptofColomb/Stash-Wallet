# User Guide – Stash Wallet

## 1. Introduction
Stash Wallet allows you to securely perform multi-blockchain transactions offline (air-gapped).

## 2. Installation
1. Extract the ZIP file.

2. Run the script `scripts/usb-deploy.sh` to write to the USB stick.

3. Plug the USB into the computer.
4. The interface will open automatically.
5. Transfer transactions via QR or file.