# Stash 钱包

Stash 钱包是一款多链优先、离线优先的加密货币钱包，专为安全的空气隔离操作而设计。

## 功能
- 多链支持（以太坊、比特币、索拉纳、TRON、BSC、Polygon、Avalanche）
- 二维码和文件交易签名
- AES-256 加密 + PIN 保护
- 通过 LayerZero、Wormhole、Stargate 的跨链转账
- 法币存款系统（美元/欧元/英镑）
- 质押系统（30% 折扣）
- 最多 10 个用户的推荐系统（1 个 stAG 奖励）