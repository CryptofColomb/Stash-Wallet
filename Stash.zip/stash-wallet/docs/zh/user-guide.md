# 用户指南 – Stash Wallet

## 1. 简介
Stash Wallet 是一款支持多链离线交易的安全加密钱包。

## 2. 安装
1. 解压 ZIP 文件。
2. 使用 `scripts/usb-deploy.sh` 脚本写入 USB。
3. 插入 USB 并自动启动。
4. 通过 QR 码或文件进行交易。