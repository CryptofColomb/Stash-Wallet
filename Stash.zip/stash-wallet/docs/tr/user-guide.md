# Kullanıcı Kılavuzu – Stash Wallet

## 1. Giriş
Stash Wallet, güvenli bir şekilde çoklu blockchain işlemlerini çevrimdışı (air-gapped) yapmanızı sağlar.

## 2. Kurulum
1. ZIP dosyasını çıkarın.
2. USB belleğe yazmak için `scripts/usb-deploy.sh` betiğini çalıştırın.
3. USB’yi bilgisayara takın.
4. Otomatik olarak arayüz açılacak.
5. İşlemleri QR veya dosya ile aktarın.