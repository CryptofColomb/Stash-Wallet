# Stash Cüzdan

Stash Cüzdan, çoklu zincir destekli, çevrimdışı işlemlere odaklı güvenli bir kripto cüzdanıdır.

## Özellikler
- Çoklu blockchain desteği (Ethereum, Bitcoin, Solana, TRON, BSC, Polygon, Avalanche)
- QR kod ve dosya üzerinden işlem imzalama
- AES-256 şifreleme + PIN koruma
- LayerZero, Wormhole, Stargate üzerinden çapraz zincir işlemleri
- USD/EUR/GBP yatırma sistemi
- %30 indirimli stake sistemi
- Maksimum 10 kullanıcı için referans sistemi (1 stAG ödül)