# Ví Stash

Stash Wallet là ví tiền mã hóa đa chuỗi được thiết kế để hoạt động ngoại tuyến an toàn.

## Tính năng
- Hỗ trợ nhiều chuỗi (Ethereum, Bitcoin, Solana, TRON, BSC, Polygon, Avalanche)
- Ký giao dịch qua mã QR và tệp tin
- Mã hóa AES-256 với bảo vệ bằng mã PIN
- Chuyển tiền giữa các chuỗi (LayerZero, Wormhole, Stargate)
- Hệ thống nạp tiền pháp định (USD/EUR/GBP)
- Hệ thống Stake với giảm giá 30%
- Hệ thống giới thiệu (tối đa 10 người dùng, phần thưởng 1 stAG)