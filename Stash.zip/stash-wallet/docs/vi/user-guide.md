# Hướng dẫn người dùng – Ví Stash

## 1. Giới thiệu
Stash Wallet là ví tiền mã hóa đa chuỗi được thiết kế cho giao dịch ngoại tuyến an toàn.

## 2. Cài đặt
1. Giải nén tệp ZIP.
2. Sử dụng lệnh `scripts/usb-deploy.sh` để ghi vào USB.
3. Cắm USB vào, giao diện sẽ tự động mở.
4. Thực hiện giao dịch qua QR hoặc tệp tin.