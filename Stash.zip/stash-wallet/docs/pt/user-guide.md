# Guia do Usuário – Stash Wallet

## 1. Introdução
Stash Wallet é uma carteira criptográfica multi-chain projetada para operações seguras offline.

## 2. Instalação
1. Extraia o arquivo ZIP.
2. Use o script `scripts/usb-deploy.sh` para escrever no USB.
3. Insira o USB e a interface abrirá automaticamente.
4. Transfira transações via QR ou arquivo.