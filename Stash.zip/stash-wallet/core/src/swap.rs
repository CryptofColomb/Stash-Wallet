// Swap işlemleri için temel yapı
pub fn get_swap_quote() -> Result<String, String> {
    Ok("0x1000000000000000000000000000000000000000000000000000000000000001".to_string())
}