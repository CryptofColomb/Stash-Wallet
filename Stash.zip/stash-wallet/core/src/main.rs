mod keygen;
mod encryption;
mod qrcode;
mod signing;
mod swap;
mod crosschain;

fn main() {
    // Uygulama başlangıcı burada
    println!("Stash Wallet başlatılıyor...");
}