export default function Swap() {
    return (
        <div className="swap">
            <h2>Swap</h2>
            <p>Token değiştirme ekranı burada</p>
        </div>
    );
}