export default function CrossChain() {
    return (
        <div className="crosschain">
            <h2>Çapraz Zincir</h2>
            <p>Kendi zincirinizi seçin ve gönderin</p>
        </div>
    );
}