export default function Fiat() {
    return (
        <div className="fiat">
            <h2>Fiat Yatır</h2>
            <p>EFT/IBAN ile yatırma</p>
        </div>
    );
}