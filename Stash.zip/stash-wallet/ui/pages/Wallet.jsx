export default function Wallet() {
    return (
        <div className="wallet">
            <h2>Cüzdanınız</h2>
            <p>stUSD: 100</p>
            <p>stEUR: 90</p>
            <p>stGBP: 80</p>
        </div>
    );
}